function G = sigmoid_nn(U,V)

global khandle
G = khandle(U,V);

